<?php echo e($slot); ?>

<?php /**PATH C:\xampp\htdocs\Uas_Web\laravel_backend\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>